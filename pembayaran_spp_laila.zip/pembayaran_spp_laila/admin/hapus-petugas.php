<?php

$id_petugas = $_GET['id_petugas'];

include '../koneksi.php';
$sql ="DELETE FROM  petugas WHERE id_petugas='$id_petugas'";
$query = mysqli_query($koneksi, $sql);
if($query){
   header("Location: admin.php?url=petugas"); 
}else{
 echo"<script>alert('Maaf Data Tak Tersimpan'); windom.locatin.assign('?url=petugas');</script>";
}
?>