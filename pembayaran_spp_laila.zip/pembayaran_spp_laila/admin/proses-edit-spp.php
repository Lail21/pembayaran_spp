<?php

$id_spp = $_GET['id_spp'];
$tahun = $_POST['tahun'];
$nominal = $_POST['nominal'];

include '../koneksi.php';
$sql ="UPDATE spp SET tahun='$tahun', nominal='$nominal' WHERE id_spp='$id_spp'";
$query = mysqli_query($koneksi, $sql);
if($query){
   header("Location: admin.php?url=spp"); 
}else{
 echo"<script>alert('Maaf Data Tak Tersimpan'); windom.locatin.assign('?url=spp');</script>";
}
?>