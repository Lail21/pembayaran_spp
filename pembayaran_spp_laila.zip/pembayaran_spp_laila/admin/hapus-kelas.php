<?php
$id_kelas = $_GET['id_kelas'];

include '../koneksi.php';
$sql ="DELETE FROM kelas WHERE id_kelas='$id_kelas'";
$query = mysqli_query($koneksi, $sql);
if($query){
   header("Location: admin.php?url=kelas"); 
}else{
 echo"<script>alert('Apakah ingin Dihapus'); windom.locatin.assign('?admin.php?url=kelas');</script>";
}
?>