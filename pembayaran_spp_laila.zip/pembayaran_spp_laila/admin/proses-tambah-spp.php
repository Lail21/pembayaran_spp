<?php
$tahun = $_POST['tahun'];
$nominal = $_POST['nominal'];

include '../koneksi.php';
$sql ="INSERT INTO spp(tahun,nominal) VALUES('$tahun','$nominal')";
$query = mysqli_query($koneksi, $sql);
if($query){
   header("Location: admin.php?url=spp"); 
}else{
 echo"<script>alert('Maaf Data Tak Tersimpan'); windom.locatin.assign('?url=spp');</script>";
}
?>