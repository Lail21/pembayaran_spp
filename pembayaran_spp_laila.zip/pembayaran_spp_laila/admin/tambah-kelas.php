<h5>Halaman Tambah kelas.</h5>
<a href="?url=kelas" class="btn btn-primary">BACK</a>
<hr>
<form  method="post" action="?url=proses-tambah-kelas">
 <div class="form-group mb-2">
  <label > Nama Kelas </label>
    <input type="text" name="nama_kelas"  class="form-control"   required>
 </div>
 <div class="form-group mb-2">
  <label> Kompotensi</label>
    <input type="text" name="kompetensi_keahlian"  class="form-control" required>
 </div>
 <div class="form-group">
   <button type="submit" class="btn btn-success">Simpan</button>
   <button type="reset" class="btn btn-warning">Riset</button>
 </div>
</form>
 
